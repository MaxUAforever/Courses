function pageRedirect(ref){
    window.location.href = ref;
};